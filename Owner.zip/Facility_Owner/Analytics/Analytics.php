<?php
include 'Analytics.html';
exit;
?>