function openModal() {
  document.getElementById("adminModal").style.display = "block";
}

function closeModal() {
  document.getElementById("adminModal").style.display = "none";
}
