<?php
include  '../navbar.html';
include  '../sportsScroll.html';
include 'JoinGroup.html'
?>