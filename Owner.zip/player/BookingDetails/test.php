<?php
session_start();
// TEMP for testing
$_SESSION['username'] = 'Bakir';

include 'test.html'; 
exit();
?>